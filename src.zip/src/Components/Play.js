import react from 'react'


const PlayandPauseToggle = ({isPlaying, onclick}) => {
    return <toggle onclick >{isPlaying ? 'Pause' : 'Play'}</toggle>;

};

export default PlayandPauseToggle