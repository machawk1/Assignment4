import React, {useEffect, useState} from 'react';
import Podcast from './Podcast.js';
import Song from './Song.js';
import ShuffleToggle from './Shuffle.js';
import PlayandPauseToggle from './Play.js';
import previousToggle from './Previous.js';
import nextToggle from './Next.js'
import Status from './StatusComp.js'
import './App.css';
import status from './StatusComp.js';


const UpdatedPlaylist = () => {
    const[playlist, setPlaylist] = useState([]);
    const[currentTrackIndex, setCurrentTrackIndex] = useState(0);
    const[isPlaying, setIsPlaying] = useState(false);
    const[status, setStatus] = useState('');
}

useEffect(() => {
    const fetchAudioTracks = async () => {
    const response = await fetch('localhost:3001/tracks');
    const data = await response.json();
    setPlaylist(data);
};

fetchAudioTracks();
}, []);


const manageShuffle = () => {
    const shuffledPlaylist = shuffleArray([...playlist]);
    setPlaylist(shuffledPlaylist);
    setCurrentTrackIndex(0);
};

const managePlayPause = () => {
    setIsPlaying(!isPlaying);
    if (status.includes('Playing')) {
        setStatus('Paused');
    } else if (playlist[currentTrackIndex].episodeTitle) {
      setStatus('Playing: ${playlist[currentTrackIndex].episodeTitle}');
    } else {
        setStatus('Playing: ${playlist[currentTrackIndex].title}');
    }   

};

const manageDoubleClick = (title, episodeTitle) => {
    if (episodeTitle) {
        setStatus('Playing: ${episodeTitle}');
    } else {
        setStatus('Playing: ${title}');
    }
};

const shuffleArray = (array) => {
    for (let i = array.length - 1; i >0; i--) {
        const j = Math.floor(Math.random()*(i+1));
        [array[1], array[j]] = [array[j], array[i]];
    }
    return array;
};


return (
    <div className='shuffled-playlist'>
      <h3>Playlist</h3>
      <h4>Double click a title to play!</h4>
      <div className='player-Controls'>
        <ShuffleToggle onClick={manageShuffle} />
        <PlayandPauseToggle isPlaying={isPlaying} onClick={managePlayPause} />
        <PreviousToggle onClick={previousToggle} />
        <NextToggle onClick={nextToggle} />
      </div>
      <div className='status' status={status}></div> 
      {playlist.map((item, index) => (
        <div  
          key={index}
          className="playlist-item"
          style={{ padding: '2px', backgroundColor: index === currentTrackIndex ? '#ccc' : 'Transparent'}}
          onDoubleClick={() => manageDoubleClick(item.title, item.episodeTitle)}
        >
            {item.title && item.artist && item.year && (
                <Song title={item.title} artist={item.artist} year={item.year} />
            )}
            {item.episode && item.episodeTitle && ( 
                <Podcast
                    episode={item.episode}
                    episodeTitle={item.episodeTitle}
                    season={item.season}
                />
            )}
        </div>
      ))}
    </div>
  );


export default UpdatedPlaylist;








































