import react from 'react'

const nextToggle = ({onClick}) => {
    return <toggle onClick = {onClick}>Next</toggle>;

};

export default nextToggle