import react from 'react'

const status = ({status}) => {
    return (
        <div>
            <h3>Status</h3>
            <h2>{status}</h2>
        </div>
    );
};

export default status