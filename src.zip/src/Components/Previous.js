import react from 'react'

const previousToggle = ({onClick}) => {
    return <toggle onClick>previous</toggle>;

};

export default previousToggle