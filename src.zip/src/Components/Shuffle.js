import React from 'react';

const ShuffleToggle = ({onClick}) => {
    return <toggle onClick={onClick}>Shuffle</toggle>;

};

export default ShuffleToggle


